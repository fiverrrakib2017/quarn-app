

<template>
  <div class="row">
    <div class="col-md-7 mx-auto">
      <div class="card shadow">
        <div class="card-header">

        </div>
        <div class="card-body">
          <div class="row">
            <div class="col-sm-4">
              <div class="form-group">
                <label for=""><b>Select Surah</b></label>
                <select @change="getSpecificSura" id="" class="form-select">
                  <option value="">Select Surah</option>

                  <option  v-for="sura in suras" :value="sura.number">{{ sura.name }} - {{ sura.englishName }}</option>
                  
                </select>
              </div>
            </div>
            <div class="col-sm-4">
              <div class="form-group text-center mt-3">
                <label for=""><b>Al-Baqrah</b></label><br>
                The Cow
              </div>
            </div>
            <div class="col-sm-4">
              <div class="form-group">
                <label for=""><b>Select Ayaht</b></label>
                <select name="" id="" class="form-select">
                  <option value="">Select Ayaht</option>
                  <option  v-for="sura in suras" value="{{sura.number}}">{{ sura.numberOfAyahs }}</option>
                </select>
              </div>
            </div>
          </div>
          <div class="row mt-4">
            <div v-if="loading" class="spinner-border " role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
            <div v-else class="col-sm-12 ">
              <p class="text-center" v-if="currentSura.hasOwnProperty('ayahs')" v-for="ayah in currentSura.ayahs">
              <span>{{ ayah.numberInSurah }}-{{ ayah.text }}</span>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>


<script >
  export default ({
    data(){
      return {
        suras:[],
        currentSura:[],
        loading:true
      }
    },
    mounted(){
      axios.get("https://api.alquran.cloud/v1/surah")
      .then(response=>{
        this.suras=response.data.data;
      })

      this.querySpecificSura(1);

    },
    methods:{
      getSpecificSura(e){
        this.querySpecificSura(e.target.value);
      },
      querySpecificSura(suraNumber){
        this.loading=true;
        axios.get("https://api.alquran.cloud/v1/surah/"+suraNumber)
      .then(response=>{
        this.currentSura=response.data.data;
        this.loading=false;
      })
      }
    }
  });
</script>